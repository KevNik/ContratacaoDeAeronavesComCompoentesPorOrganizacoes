componentes = {}


def get_componentes(): return componentes


def inserir_componente(componente):
    nome_componente = componente.nome
    if nome_componente in get_componentes().keys():
        print(f'Componente {nome_componente} já cadastrado')
        return False

    componentes[nome_componente] = componente
    return True


class Componente:
    def __init__(self, nome, tipo, essencial):
        self.nome = nome
        self.tipo = tipo if tipo in ('elétrico', 'mecânico') else 'indefinido'
        self.essencial = essencial

    def __str__(self):
        if self.essencial:
            essencial_str = 'essencial'
        else:
            essencial_str = ''

        formato = '{} {:<20} {} {:<8} {} {:<10} {}'
        componente_formatado = formato.format('|', self.nome, '|', self.tipo, '|', essencial_str, '|')
        return componente_formatado
