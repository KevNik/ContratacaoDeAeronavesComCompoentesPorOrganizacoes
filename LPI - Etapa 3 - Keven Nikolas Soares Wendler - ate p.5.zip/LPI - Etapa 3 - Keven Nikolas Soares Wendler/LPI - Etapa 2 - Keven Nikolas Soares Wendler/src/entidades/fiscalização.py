from entidades.aeronave import get_aeronaves
from entidades.aeroporto import get_aeroportos
from entidades.componente import ComponenteEstrutural, ComponenteEletronico

fiscalizacoes = []


def get_fiscalizacoes(): return fiscalizacoes


def inserir_fiscalizacao(fiscalizacao):
    if fiscalizacao not in fiscalizacoes:
        fiscalizacoes.append(fiscalizacao)
    else:
        print('Fiscalização de aeronave já cadastrada --- ' + str(fiscalizacao))


def criar_fiscalizacao(sigla_aeroporto, prefixo_aeronave, data):
    aeronave = get_aeronaves()[prefixo_aeronave]
    if aeronave is None:
        print(f'Aeronave {prefixo_aeronave} não cadastrada')
        return

    aeroporto = get_aeroportos()[sigla_aeroporto]
    if not aeroporto:
        print(f'Aeroporto {sigla_aeroporto} não cadastrado')
        return False

    fiscalizacao = Fiscalizacao(data, aeroporto, aeronave)
    inserir_fiscalizacao(fiscalizacao)


def selecionar_fiscalizacoes(data_minima_fiscalizacao=None, estado_aeroporto=None, marca_aeronave=None, tipo_componente=None, material_componente_estrutural=None, de_navegacao_componente_eletronico=None):
    fiscalizacoes_selecionadas = []
    filtros = '\nFiltros -- '

    if data_minima_fiscalizacao is not None: filtros += ' - data mínima da fiscalização: ' + str(data_minima_fiscalizacao)
    if marca_aeronave is not None: filtros += ' - marca da aeronave: ' + marca_aeronave
    if estado_aeroporto is not None: filtros += ' - estado do aeroporto: ' + estado_aeroporto
    if tipo_componente is not None: filtros += ' - tipo do componente: ' + tipo_componente

    for fiscalizacao in fiscalizacoes:
        if data_minima_fiscalizacao is not None and fiscalizacao.data.__lt__(data_minima_fiscalizacao): continue
        if marca_aeronave is not None and fiscalizacao.aeronave.marca != marca_aeronave: continue
        if estado_aeroporto is not None and fiscalizacao.aeroporto.estado != estado_aeroporto: continue

        if tipo_componente is not None:
            fiscalizacao.aeronave.componentes_selecionados = {}
            for componente in fiscalizacao.aeronave.componentes.values():
                ignorar_componente = False
                if tipo_componente is not None and tipo_componente != componente.tipo:
                    ignorar_componente = True

                if isinstance(componente, ComponenteEstrutural):
                    if material_componente_estrutural is not None and componente.material != material_componente_estrutural:
                        ignorar_componente = True

                if isinstance(componente, ComponenteEletronico):
                    if de_navegacao_componente_eletronico is not None and componente.de_navegacao != de_navegacao_componente_eletronico:
                        ignorar_componente = True

                if ignorar_componente: continue
                else: fiscalizacao.aeronave.componentes_selecionados[componente.nome] = componente

        fiscalizacoes_selecionadas.append(fiscalizacao)

    return filtros, fiscalizacoes_selecionadas


class Fiscalizacao:
    def __init__(self, data, aeroporto, aeronave):
        self.data = data
        self.aeroporto = aeroporto
        self.aeronave = aeronave

    def __str__(self):
        formato = '{} {:<5} {} {:<6} {} {:<10} '
        fiscalizacao_formatada = formato.format('|', str(self.data), '|', self.aeronave.prefixo, '|', self.aeroporto.prefixo)
        return fiscalizacao_formatada

    def str_atributos_componentes(self):
        atributos_componentes_str = ''
        tem_componentes_filtrados = len(self.aeronave.componentes_selecionados) > 0
        componentes = self.aeronave.componentes_selecionados if tem_componentes_filtrados else self.aeronave.componentes
        for indice, componente in enumerate(componentes.values()):
            if indice > 0: atributos_componentes_str += ' -- '
            atributos_componentes_str += f'{componente.tipo}'
            if isinstance(componente, ComponenteEletronico): atributos_componentes_str += ' (navegação)' if componente.de_navegacao else ''
            elif isinstance(componente, ComponenteEstrutural): atributos_componentes_str += f' ({componente.material})'

        return atributos_componentes_str

    def str_filtro(self):
        formato = '{} {:<8} {} {:<80} {} {:<18} {}'
        filtro_formatado = formato.format('|', self.aeronave.marca, '|', self.str_atributos_componentes(), '|', self.aeroporto.estado, '|')
        return self.__str__() + filtro_formatado
