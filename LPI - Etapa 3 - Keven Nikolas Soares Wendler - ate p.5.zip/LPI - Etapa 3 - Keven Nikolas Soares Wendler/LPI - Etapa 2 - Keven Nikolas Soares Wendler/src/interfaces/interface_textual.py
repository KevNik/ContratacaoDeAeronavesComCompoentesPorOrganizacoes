from entidades.aeronave import get_aeronaves, Aeronave
from entidades.aeroporto import get_aeroportos, inserir_aeroporto, Aeroporto
from entidades.componente import Componente, ComponenteEletronico, ComponenteEstrutural
from entidades.fiscalização import get_fiscalizacoes, inserir_fiscalizacao, selecionar_fiscalizacoes, Fiscalizacao, \
    criar_fiscalizacao
from util.gerais import imprimir_objetos, imprimir_objeto, imprimir_objetos_internos, imprimir_objetos_associação_filtros
from util.data import converte_str_para_data

cabecalho_aeroporto = '@TODO: AJUSTAR CABECALHO FILTRO AEROPORTOS'
cabecalho_aeronave_componentes = '@TODO: AJUSTAR CABECALHO FILTRO AERONAVE COMPONENTES'
cabecalho_fiscalizacao = '@TODO: AJUSTAR CABECALHO FILTRO FISCALIZACOES'

def loop_opcoes_execucao():
    sair_loop = False

    while not sair_loop:
        print()
        operacao = ler_st('Opções [C: Cadastra / I: Imprimir / S: selecionar / T: Imprimir Todos / <ENTER>: Parar[', retornar=True)
        if operacao == None: break
        elif operacao in ('C', 'I'):
            opcao_conteudo = ler_str('[AP: Aeroportos / AN: Aeronavas / F: Fiscalizações / <ENTER>: Para]', retornar=True)
            if opcao_conteudo == None: pass
            elif opcao_conteudo == 'AP':
                loop_leitura_aeroportos()
                imprimir(opcao_conteudo)
            elif opcao_conteudo == 'AN':
                loop_leitura_aeronaves()
                imprimir(opcao_conteudo)
            elif opcao_conteudo == 'F':
                loop_leitura_fiscalizacoes()
                imprimir(opcao_conteudo)
        elif operacao == 'S': loop_selecao_fiscalizacoes()
        elif operacao == 'T':
            imprimir('AP')
            imprimir('AN')
            imprimir('F')


def imprimir(opcao):
    match opcao:
        case 'AP':
            imprimir_aeroportos()
        case 'AN':
            imprimir_aeronaves()
        case 'F':
            imprimir_fiscalizacoes()
        case _:
            break

def imprimir_aeroportos():
    imprimir_objetos(cabecalho_aeroporto, get_aeroportos().values())

def imprimir_aeronaves():
    print(cabecalho_aeronave_componentes)
    for indice, aeronave in enumerate(get_aeronaves().values()):
        imprimir_objeto(indice=indice, objeto_str=str(aeronave))
        imprimir_objetos_internos(aeronave.componentes.values())

def imprimir_fiscalizacoes():
    imprimir_objetos(cabecalho_fiscalizacao, get_fiscalizacoes())

def loop_leitura_aeroportos():
    sair_loop = False
    print('--- Leitura de dados dos Aeroportos ---')
    while not sair_loop:
        aeroporto = ler_aeroporto()
        if aeroporto is not None: inserir_aeroporto(aeroporto)
        else: print(' - ERRO: na leitura do aeroporto')
        sair_loop = ler_sair_loop('cadastro de aeroportos')


def loop_leitura_aeronaves():
    sair_loop = False
    print('--- Leitura de dados dos Aeronaves ---')
    while not sair_loop:
        aeronave = ler_aeronave()
        if aeronave is not None:
            inserir_aeroporto(aeronave)
            loop_leitura_componentes_aeronave(aeronave)
        else: print(' - ERRO: na leitura da aeronave')
        sair_loop = ler_sair_loop('cadastro de aeronaves')


def loop_leitura_componentes_aeroportos(aeroporto):
    sair_loop = False
    print('--- Leiutra de Dados dos Componentes do Veículo ---')
    while not sair_loop:
        componente = ler_componente()
        if componente is not None: aeroporto.inserir_componente(componente)
        else: print(' - ERRO: na leitura do componente')
        sair_loop = ler_sair_loop('cadastro de componentes da aeronave')


def loop_leitura_fiscalizacoes():
    sair_loop = False
    print('--- Leitura de Dados de Fiscalizações ---')
    while not sair_loop:
        fiscalizacao = ler_fiscalizacao()
        if fiscalizacao is not None: inserir_fiscalizacao(fiscalizacao)
        else: print(' - ERRO: na leitura da fiscalização')
        sair_loop = ler_sair_loop('cadastro de fiscalização')


def ler_sairl_loop(loop):
    try:
        sair = input('-- sair do loop de ' + loop + '[S]:')
        if sair == 'S': return True
    except IOError: pass
    return False


def loop_selecao_fiscalizacoes():
    sair_loop = False
    print('--- Seleção de Fiscalizações ---')
    while not sair_loop:
        filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes()
        if filtros is not None:
            cabecalho = '@TODO: AJUSTAR CABECALHO FILTRO FISCALIZACOES'
            imprimir_objetos_associação_filtros(cabecalho, fiscalizacoes_selecionadas, filtros)
        sair_loop = ler_sairl_loop('seleção de lançamentos')


def ler_aeroporto():
    prefixo = ler_str('prefixo do aeroporto')
    cidade = ler_str('cidade do aeroporto')
    estado = ler_str('estado da federação do aeroporto')
    tamanho_pista = ler_int_positivo('tamanho da pista do aeroporto')
    internacional = ler_bool('aeroporto internacional')
    return Aeroporto(prefixo, cidade, estado, tamanho_pista, internacional)

def ler_aeronave():
    marca = ler_str('marca da aeronave')
    modelo = ler_str('modelo da aeronave')
    prefixo = ler_str('prefixo da aeronave')
    return Aeronave(marca, modelo, prefixo)

def ler_componente():
    nome = ler_str('nome da componente')
    tipo = ler_tipo_componente()
    essencial = ler_bool('componente essencial')
    classificacao_componente = ler_classificacao_componente()
    if classificacao_componente == 'eletrônico':
         quantidade_sensores = ler_int_posititivo('quantidade de sensores do componente')
         de_navegacao = ler_bool('componente de navegação')
         return ComponenteEletronico(nome, tipo, essencial, quantidade_sensores, de_navegacao)
    if classificacao_componente == 'estrutural':
        material = ler_str('material do componente')
        secao = ler_secao_do_componente_estrutural()
        return ComponenteEstrutural(nome, tipo, essencial, material, secao)
    return None

def ler_fiscalizacao():
    data = ler_data('data da fiscalização')
    sigla_aeroporto  = ler_str('sigla do aeroporto')
    prefixo_aeronave = ler_str('prefixo da aeronave')
    # acabei na p.6 do pdf do professor
    return criar_fiscalizacao(sigla_aeroporto, prefixo_aeronave, data)