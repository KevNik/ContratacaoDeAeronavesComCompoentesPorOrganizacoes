componentes = {}


def get_componentes(): return componentes


def inserir_componente(componente):
    nome_componente = componente.nome
    if nome_componente in get_componentes().keys():
        print(f'Componente {nome_componente} já cadastrado')
        return False

    componentes[nome_componente] = componente
    return True


class Componente:
    def __init__(self, nome, tipo, essencial):
        self.nome = nome
        self.tipo = tipo if tipo in ('elétrico', 'mecânico') else 'indefinido'
        self.essencial = essencial

    def __str__(self):
        if self.essencial:
            essencial_str = 'essencial'
        else:
            essencial_str = ''

        formato = '{} {:<20} {} {:<8} {} {:<10} {}'
        componente_formatado = formato.format('|', self.nome, '|', self.tipo, '|', essencial_str, '|')
        return componente_formatado


class ComponenteEletronico(Componente):
    def __init__(self, nome, tipo, essencial, quantidade_sensores, de_navegacao):
        super().__init__(nome, tipo, essencial)
        self.quantidade_sensores = quantidade_sensores
        self.de_navegacao = de_navegacao

    def __str__(self):
        if self.essencial:
            essencial_str = 'essencial'
        else:
            essencial_str = ''

        if self.de_navegacao:
            navegacao_str = 'navegação'
        else:
            navegacao_str = ''

        formato = '{} {:<20} {} {:<8} {} {:<10} {} {:<14} {} {:<14} {}'
        componente_formatado = formato.format('|', self.nome, '|', self.tipo, '|', essencial_str, '|', self.quantidade_sensores, '|', navegacao_str, '|')
        return componente_formatado


class ComponenteEstrutural(Componente):
    def __init__(self, nome, tipo, essencial, material, secao):
        super().__init__(nome, tipo, essencial)
        self.material = material
        self.secao = secao if secao in ('fuselagem', 'empenagem', 'asas', 'motor-propulsor', 'trem-de-pouso') else 'indefinido'

    def __str__(self):
        if self.essencial:
            essencial_str = 'essencial'
        else:
            essencial_str = ''

        formato = '{} {:<20} {} {:<8} {} {:<10} {} {:<14} {} {:<14} {}'
        componente_formatado = formato.format('|', self.nome, '|', self.tipo, '|', essencial_str, '|', self.secao, '|', self.material, '|')
        return componente_formatado