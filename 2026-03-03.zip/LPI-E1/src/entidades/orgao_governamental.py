orgaos_governamentais = []

def get_orgaos_governamentais(): return orgaos_governamentais

def inserir_orgao_governamental(orgao_governamental): orgaos_governamentais.append(orgao_governamental)

def selecionar_orgaos_governamentais(nome=None, setor=None, secreto=None):
    orgaos_governamentais_selecionados = []

    return orgaos_governamentais_selecionados

class OrgaoGovernamental:
    def __init__(self, nome, setor, secreto):
        self.nome = nome
        self.setor = setor if setor in ('defesa', 'logistica', 'aeroespacial') else 'indefinido'
        self.secreto = secreto

    def __str__(self):
        if self.secreto: secreto = 'secreto |'
        else: secreto = ''
        formato = '{} {} {} {} {} {}'
        orgao_governamental_formatado = formato.format('|', self.nome, '|', self.setor, '|', secreto)
        return orgao_governamental_formatado