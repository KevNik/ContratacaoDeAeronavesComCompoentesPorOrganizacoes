class Aeronave:
    def __init__(self, marca, modelo, potencia):
        self.marca = marca
        self.modelo = modelo
        self.potencia = potencia

    def __str__(self):
        aeronave_formatada = ''

        return aeronave_formatada
