from util.gerais import imprimir_objetos
if __name__ == 'main':
    cabecalho = 'OrgaosGovernamentais : '
    imprimir_objetos()