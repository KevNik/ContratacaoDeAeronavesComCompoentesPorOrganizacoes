from util.gerais import imprimir_objetos, imprimir_objeto
from util.data import Data
from entidades.aeroporto import (Aeroporto, get_aeroportos, inserir_aeroporto)
from entidades.componente import (Componente, ComponenteEstrutural, ComponenteEletronico, get_componentes,
                                  inserir_componente)
from entidades.fiscalização import (criar_fiscalizacao, get_fiscalizacoes, selecionar_fiscalizacoes)
from entidades.aeronave import (inserir_aeronave, get_aeronaves, Aeronave)


def cadastrar_componentes():
    inserir_componente(Componente('Flaps', 'mecânico', True))
    inserir_componente(Componente('Bomba de combustível', 'elétrico', True))
    inserir_componente(ComponenteEstrutural('Trem de pouso', 'mecânico', True, 'alumínio', 'trem-de-pouso'))
    inserir_componente(ComponenteEstrutural('Coluna', 'mecânico', True, 'titânio', 'fuselagem'))
    inserir_componente(ComponenteEletronico('Radar', 'elétrico', True, 'silício', True))
    inserir_componente(ComponenteEletronico('Transponder', 'elétrico', False, 'sílicio', True))
    inserir_componente(ComponenteEstrutural('Asa', 'mecânico', False, 'alumínio', 'asas'))


def cadastrar_aeroportos():
    inserir_aeroporto(Aeroporto('DOU', 'Dourados', 'Mato grosso do sul', 1500, False))
    inserir_aeroporto(Aeroporto('GRU', 'Guarulhos', 'São Paulo', 2500, False))
    inserir_aeroporto(Aeroporto('VCP', 'Campinas', 'São Paulo', 2500, True))
    inserir_aeroporto(Aeroporto('CGH', 'São Paulo', 'São Paulo', 2500, True))
    inserir_aeroporto(Aeroporto('FLN', 'Florianópolis', 'Santa Catarina', 3500, False))


def cadastrar_aeronaves():
    a1 = Aeronave(marca='Boeing', modelo='777', prefixo='PPT01')
    a1.inserir_componentes(['Radar', 'Bomba de combustível', 'Trem de pouso'])
    inserir_aeronave(a1)
    a2 = Aeronave(marca='Boeing', modelo='707', prefixo='PPT02')
    a2.inserir_componentes(['Bomba de combustível', 'Trem de pouso', 'Asa'])
    inserir_aeronave(a2)
    a3 = Aeronave(marca='Embraer', modelo='Jet 170', prefixo='BBT02')
    a3.inserir_componentes(['Radar', 'Bomba de combustível', 'Trem de pouso', 'Asa'])
    inserir_aeronave(a3)
    a4 = Aeronave(marca='Boeing', modelo='747', prefixo='PPT03')
    a4.inserir_componentes(['Radar', 'Bomba de combustível', 'Trem de pouso', 'Asa', 'Porta de emergência'])
    inserir_aeronave(a4)


def cadastrar_fiscalizacoes():
    criar_fiscalizacao(sigla_aeroporto='DOU', prefixo_aeronave='BBT02', data=Data(2, 9, 2020))
    criar_fiscalizacao(sigla_aeroporto='DOU', prefixo_aeronave='PPT03', data=Data(2, 9, 2020))
    criar_fiscalizacao(sigla_aeroporto='GRU', prefixo_aeronave='PPT02', data=Data(2, 9, 2021))
    criar_fiscalizacao(sigla_aeroporto='VCP', prefixo_aeronave='BBT02', data=Data(2, 9, 2022))
    criar_fiscalizacao(sigla_aeroporto='CGH', prefixo_aeronave='PPT01', data=Data(2, 9, 2023))


def imprimir_objetos_associacao_filtros(cabecalho, objetos, filtros=None):
    if filtros is not None: print(filtros)
    print(cabecalho)
    for indice, objeto in enumerate(objetos):
        imprimir_objeto(indice, objeto.str_filtro())


def imprimir_objetos_internos(objetos):
    for objeto in objetos: print('      ' + str(objeto))


def imprimir_somente_para_alinhar_formatacao():
    print('\nAeronaves: Prefixo - Marca - Modelo')
    print('- Componentes: Nome - Tipo - Essencial')
    for indice, aeronave in enumerate(get_aeronaves().values()):
        imprimir_objeto(indice, str(aeronave))
        imprimir_objetos_internos(aeronave.componentes.values())


if __name__ == '__main__':
    print('\nFiscalização de Componentes de uma Aeronave por Aeroporto')
    cadastrar_componentes()
    imprimir_objetos(
        '\nComponentes: nome - tipo - essencial - eletrônico:[quantidade de sensores - de navegação] | estrutural:[seção - material] ',
        objetos=get_componentes().values())

    cadastrar_aeroportos()
    imprimir_objetos('\nAeroportos: prefixo - cidade - estado - internacional', objetos=get_aeroportos().values())

    cadastrar_aeronaves()
    imprimir_objetos('\nAeronaves: prefixo - marca - modelo', objetos=get_aeronaves().values())
    imprimir_somente_para_alinhar_formatacao()

    cadastrar_fiscalizacoes()
    cabecalho_fiscalizacao = '\nFiscalização: Data - Aeronave - Aeroporto'
    imprimir_objetos(cabecalho_fiscalizacao, objetos=get_fiscalizacoes())

    cabecalho_fiscalizacao_filtros = cabecalho_fiscalizacao + '\n-- Data mínima fiscalização - Marca da Aeronave - Componentes Fiscalizados - Estado'
    filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes()
    imprimir_objetos_associacao_filtros(cabecalho_fiscalizacao_filtros, objetos=fiscalizacoes_selecionadas,
                                        filtros=filtros)

    filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes(data_minima_fiscalizacao=Data(3, 9, 2020))
    imprimir_objetos_associacao_filtros(cabecalho_fiscalizacao_filtros, objetos=fiscalizacoes_selecionadas,
                                        filtros=filtros)

    filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes(data_minima_fiscalizacao=Data(3, 9, 2020),
                                                                   nome_componente='Radar')
    imprimir_objetos_associacao_filtros(cabecalho_fiscalizacao_filtros, objetos=fiscalizacoes_selecionadas,
                                        filtros=filtros)

    filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes(data_minima_fiscalizacao=Data(3, 9, 2020),
                                                                   nome_componente='Radar', marca_aeronave='Boeing')
    imprimir_objetos_associacao_filtros(cabecalho_fiscalizacao_filtros, objetos=fiscalizacoes_selecionadas,
                                        filtros=filtros)

    filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes(data_minima_fiscalizacao=Data(3, 9, 2020),
                                                                   nome_componente='Radar', marca_aeronave='Boeing',
                                                                   estado_aeroporto='São Paulo')
    imprimir_objetos_associacao_filtros(cabecalho_fiscalizacao_filtros, objetos=fiscalizacoes_selecionadas,
                                        filtros=filtros)
