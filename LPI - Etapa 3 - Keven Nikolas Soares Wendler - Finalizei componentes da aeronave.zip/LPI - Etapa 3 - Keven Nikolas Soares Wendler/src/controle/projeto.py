#   TER PELO MENOS 9 OBJETOS
# 1 - FILTRAR ASSOCIADORA => DIMINUI UM
# 2 - FILTRAR SEM REFERENCIA => DIMINUI UM
# 3 - RELCAIONAMENTO -> SO SELECIONA A LINHA SE TODOS ATENDEM -> FILTRAR A FISCALIZACA TODA => DIMINUI UM
# TEM QUE SOBRAR 6 OBJETOS AQUI
# FILTRAR SUBCLASSE (HERANCA 1)
# SUBCLASSE
# SUBCLASSE
# FILTRAR SUBCLASSE (HERANCA 2)
# SUPERCLASS
# SUBCLASSE
# SUBCLASSE

from entidades.aeronave import (get_aeronaves, set_aeronaves)
from entidades.aeroporto import (get_aeroportos, set_aeroportos)
from entidades.componente import (get_componentes, set_componentes)
from entidades.fiscalização import (get_fiscalizacoes, set_fiscalizacoes)
from interfaces.interface_textual import loop_opcoes_execucao
from util.persistencia_arquivo import salvar_arquivo, carregar_arquivo

nome_arquivo = 'arquivo'


def salvar_aplicacao():
    aplicacao = {}
    aplicacao.update({'componentes': get_componentes()})
    aplicacao.update({'aeroportos': get_aeroportos()})
    aplicacao.update({'aeronaves': get_aeronaves()})
    aplicacao.update({'fiscalizacoes': get_fiscalizacoes()})
    salvar_arquivo(nome_arquivo, objetos=aplicacao)


def recuperar_aplicacao():
    aplicacao = carregar_arquivo(nome_arquivo)
    if aplicacao is not None:
        set_componentes(aplicacao.get('componentes'))
        set_aeroportos(aplicacao.get('aeroportos'))
        set_aeronaves(aplicacao.get('aeronaves'))
        set_fiscalizacoes(aplicacao.get('fiscalizacoes'))


if __name__ == '__main__':
    recuperar_aplicacao()
    loop_opcoes_execucao()
    salvar_aplicacao()