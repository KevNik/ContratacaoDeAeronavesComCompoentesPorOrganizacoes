from entidades.aeronave import get_aeronaves, Aeronave
from entidades.aeroporto import get_aeroportos, inserir_aeroporto, Aeroporto
from entidades.componente import ComponenteEletronico, ComponenteEstrutural, get_componentes, Componente, \
    inserir_componente
from entidades.fiscalização import get_fiscalizacoes, inserir_fiscalizacao, selecionar_fiscalizacoes, criar_fiscalizacao
from util.gerais import imprimir_objetos, imprimir_objeto, imprimir_objetos_internos, imprimir_objetos_associação_filtros
from util.data import converte_str_para_data

cabecalho_componentes = '@TODO: AJUSTAR CABECALHO FILTRO COMPONENTES'
cabecalho_aeroporto = '@TODO: AJUSTAR CABECALHO FILTRO AEROPORTOS'
cabecalho_aeronave_componentes = '@TODO: AJUSTAR CABECALHO FILTRO AERONAVE COMPONENTES'
cabecalho_fiscalizacao = '@TODO: AJUSTAR CABECALHO FILTRO FISCALIZACOES'


def loop_opcoes_execucao():
    sair_loop = False

    while not sair_loop:
        print()
        operacao = ler_str('Opções [C: Cadastra / I: Imprimir / S: selecionar / T: Imprimir Todos / <ENTER>: Parar]', retornar=True)
        if operacao is None: break
        elif operacao in ('C', 'I'):
            opcao_conteudo = ler_str('[C: Componentes / AP: Aeroportos / AN: Aeronavas / F: Fiscalizações / <ENTER>: Para]', retornar=True)
            if opcao_conteudo is None: pass
            elif opcao_conteudo == 'C':
                loop_leitura_componentes()
                imprimir(operacao)
            elif opcao_conteudo == 'AP':
                loop_leitura_aeroportos()
                imprimir(opcao_conteudo)
            elif opcao_conteudo == 'AN':
                loop_leitura_aeronaves()
                imprimir(opcao_conteudo)
            elif opcao_conteudo == 'F':
                loop_leitura_fiscalizacoes()
                imprimir(opcao_conteudo)
        elif operacao == 'S': loop_selecao_fiscalizacoes()
        elif operacao == 'T':
            imprimir('C')
            imprimir('AP')
            imprimir('AN')
            imprimir('F')


def imprimir(opcao):
    match opcao:
        case 'AP':
            imprimir_aeroportos()
        case 'AN':
            imprimir_aeronaves()
        case 'F':
            imprimir_fiscalizacoes()
        case 'C':
            imprimir_componentes()

def imprimir_aeroportos():
    imprimir_objetos(cabecalho_aeroporto, get_aeroportos().values())

def imprimir_aeronaves():
    print(cabecalho_aeronave_componentes)
    for indice, aeronave in enumerate(get_aeronaves().values()):
        imprimir_objeto(indice=indice, objeto_str=str(aeronave))
        imprimir_objetos_internos(aeronave.componentes.values())

def imprimir_fiscalizacoes():
    imprimir_objetos(cabecalho_fiscalizacao, get_fiscalizacoes())

def imprimir_componentes():
    imprimir_objetos(cabecalho_componentes, get_componentes().values())

def loop_leitura_aeroportos():
    sair_loop = False
    print('--- Leitura de dados dos Aeroportos ---')
    while not sair_loop:
        aeroporto = ler_aeroporto()
        if aeroporto is not None: inserir_aeroporto(aeroporto)
        else: print(' - ERRO: na leitura do aeroporto')
        sair_loop = ler_sair_loop('cadastro de aeroportos')


def loop_leitura_aeronaves():
    sair_loop = False
    print('--- Leitura de dados dos Aeronaves ---')
    while not sair_loop:
        aeronave = ler_aeronave()
        if aeronave is not None:
            inserir_aeroporto(aeronave)
            loop_leitura_componentes_aeronave(aeronave)
        else: print(' - ERRO: na leitura da aeronave')
        sair_loop = ler_sair_loop('cadastro de aeronaves')


def loop_leitura_componentes_aeronave(aeronave):
    sair_loop = False
    print('--- Leiutra de Dados dos Componentes da Aeronave ---')
    while not sair_loop:
        imprimir_objetos(cabecalho_componentes, get_componentes().values())
        indice_componente = ler_str('indice do componente')
        componente = get_componentes()[indice_componente]
        if componente is not None: aeronave.inserir_componentes(componente)
        else: print(' - ERRO: na leitura do componente')
        sair_loop = ler_sair_loop('cadastro de componentes da aeronave')

def loop_leitura_componentes():
    sair_loop = False
    print('--- Leiutra de Dados dos Componentes da Aeronave ---')
    while not sair_loop:
        componente = ler_componente()
        if componente is not None: inserir_componente(componente)
        else: print(' - ERRO: na leitura do componente')
        sair_loop = ler_sair_loop('cadastro de componentes da aeronave')


def loop_leitura_fiscalizacoes():
    sair_loop = False
    print('--- Leitura de Dados de Fiscalizações ---')
    while not sair_loop:
        fiscalizacao = ler_fiscalizacao()
        if fiscalizacao is not None: inserir_fiscalizacao(fiscalizacao)
        else: print(' - ERRO: na leitura da fiscalização')
        sair_loop = ler_sair_loop('cadastro de fiscalização')


def loop_selecao_fiscalizacoes():
    sair_loop = False
    print('--- Seleção de Fiscalizações ---')
    while not sair_loop:
        filtros, fiscalizacoes_selecionadas = selecionar_fiscalizacoes()
        if filtros is not None:
            cabecalho = '@TODO: AJUSTAR CABECALHO FILTRO FISCALIZACOES'
            imprimir_objetos_associação_filtros(cabecalho, fiscalizacoes_selecionadas, filtros)
        sair_loop = ler_sair_loop('seleção de lançamentos')


def ler_sair_loop(loop):
    try:
        sair = input('-- sair do loop de ' + loop + '[S]:')
        if sair == 'S': return True
    except IOError:
        pass
    return False


def ler_str(dado, filtro=False, retornar=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and (filtro or retornar): return None
        if len(string) > 0: return string
    except IOError: pass
    print('Erro na leitura do dado: ' + dado)
    return None


def ler_int_positivo(dado, filtro=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and filtro: return None
        int_positivo = int(string)
        if int_positivo > 0: return int_positivo
    except ValueError: pass
    print('Erro na leitura/conversão do inteiro positivo: ' + dado)
    return None


def ler_float_positivo(dado, filtro=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and filtro: return None
        float_positivo = float(string)
        if float_positivo > 0.0: return float_positivo
    except ValueError: pass
    print('Erro na leitura/conversão do inteiro positivo: ' + dado)
    return None


def ler_data(dado, filtro=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and filtro: return None
        data = converte_str_para_data(string)
        if data is not None: return data
    except IOError: pass
    print('Erro na leitura da data: ' + dado)
    return None

def ler_bool(dado, filtro=False):
    try:
        string = input('- ' + dado + ' [S/N]: ')
        if len(string) == 0 and filtro: return None
        if string == 'S': return True
        if string == 'N': return False
    except IOError: pass
    print('Erro na leitura do bool: ' + dado)
    return None

def ler_aeroporto():
    prefixo = ler_str('prefixo do aeroporto')
    if prefixo is None: return None
    cidade = ler_str('cidade do aeroporto')
    if cidade is None: return None
    estado = ler_str('estado da federação do aeroporto')
    if estado is None: return None
    tamanho_pista = ler_int_positivo('tamanho da pista do aeroporto')
    if tamanho_pista is None: return None
    internacional = ler_bool('aeroporto internacional')
    if internacional is None: return None

    return Aeroporto(prefixo, cidade, estado, tamanho_pista, internacional)

def ler_aeronave():
    prefixo = ler_str('prefixo da aeronave')
    if prefixo is None: return None
    marca = ler_str('marca da aeronave')
    if marca is None: return None
    modelo = ler_str('modelo da aeronave')
    if modelo is None: return None

    return Aeronave(marca, modelo, prefixo)

def ler_componente():
    nome = ler_str('nome da componente')
    if nome is None: return None
    tipo = ler_tipo_componente()
    if tipo is None: return None
    essencial = ler_bool('componente essencial')
    if essencial is None: return None
    classificacao_componente = ler_classificacao_componente()
    if classificacao_componente is None: return None
    if classificacao_componente == 'eletrônico':
         quantidade_sensores = ler_int_positivo('quantidade de sensores do componente')
         if quantidade_sensores is None: return None
         de_navegacao = ler_bool('componente de navegação')
         if de_navegacao is None: return None

         return ComponenteEletronico(nome, tipo, essencial, quantidade_sensores, de_navegacao)
    if classificacao_componente == 'estrutural':
        material = ler_str('material do componente')
        if material is None: return None
        secao = ler_secao_do_componente_estrutural()
        if secao is None: return None

        return ComponenteEstrutural(nome, tipo, essencial, material, secao)

    return Componente(nome, tipo, essencial)


def ler_tipo_componente(filtro=False):
    try:
        string = input(' - tipo do componente [E=Elétrico / M=Mecânico]')
        if len(string) == 0 and filtro: return None
        if string == 'E': return 'elétrico'
        if string == 'M': return 'mecânico'
    except IOError: pass
    print('Erro no tipo do componente')
    return None

def ler_classificacao_componente(filtro=False):
    try:
        string = input(' - classificação do componente [EL=Eletrônico / ES=Estrutural]')
        if len(string) == 0 and filtro: return None
        if string == 'EL': return 'elétrico'
        if string == 'ES': return 'mecânico'
    except IOError: pass
    print('Erro no tipo do componente')
    return None

def ler_secao_do_componente_estrutural(filtro=False):
    try:
        string = input(' - seção do componente estrutural [F=Fuselagem / E=Empenagem / A=Asas / M=Motor Propulsor / T=Trem de Pouso]')
        if len(string) == 0 and filtro: return None
        if string == 'F': return 'fuselagem'
        if string == 'E': return 'empenagem'
        if string == 'A': return 'asas'
        if string == 'M': return 'motor-propulsor'
        if string == 'T': return 'trem-de-pouso'
    except IOError: pass
    print('Erro no tipo do componente')
    return None

def ler_fiscalizacao():
    data = ler_data('data da fiscalização')
    if data is None: return None
    sigla_aeroporto  = ler_str('sigla do aeroporto')
    if sigla_aeroporto is None: return None
    prefixo_aeronave = ler_str('prefixo da aeronave')
    if prefixo_aeronave is None: return None
    return criar_fiscalizacao(sigla_aeroporto, prefixo_aeronave, data)