aeroportos = {}

def set_aeroportos(_aeroportos):
    global aeroportos
    aeroportos = _aeroportos


def get_aeroportos(): return aeroportos


def inserir_aeroporto(aeroporto):
    prefixo_aeoroporto = aeroporto.prefixo
    if prefixo_aeoroporto in get_aeroportos().keys():
        print(f'Aeroporto {prefixo_aeoroporto} já cadastrado')
        return False

    aeroportos[prefixo_aeoroporto] = aeroporto
    return True


class Aeroporto:
    def __init__(self, prefixo, cidade, estado, tamanho_pista, internacional):
        self.prefixo = prefixo
        self.cidade = cidade
        self.estado = estado
        self.internacional = internacional
        self.tamanho_pista = tamanho_pista

    def __str__(self):
        if self.internacional:
            internacional_str = 'internacional'
        else:
            internacional_str = ''
        formato = '{} {:<5} {} {:<14} {} {:<20} {} {:>5} {} {:<15} {}'
        aeroporto_formatado = formato.format('|', self.prefixo, '|', self.cidade, '|', self.estado, '|',
                                             str(self.tamanho_pista) + 'M', '|', internacional_str, '|')
        return aeroporto_formatado



