from entidades.componente import get_componentes
aeronaves = {}

def set_aeronaves(_aeronaves):
    global aeronaves
    aeronaves = _aeronaves
def get_aeronaves(): return aeronaves


def inserir_aeronave(aeronave):
    if aeronave.prefixo in aeronaves.keys():
        print(f'Aeronave {aeronave.prefixo} já cadastrada')
    aeronaves[aeronave.prefixo] = aeronave
    return True


class Aeronave:
    def __init__(self, marca, modelo, prefixo):
        self.marca = marca
        self.modelo = modelo
        self.prefixo = prefixo
        self.componentes = {}
        self.componentes_selecionados = {}

    def __str__(self):
        formato = '{} {:<20} {} {:<10} {} {:<7} {}'
        aeronave_formatada = formato.format('|', self.prefixo, '|', self.marca, '|', self.modelo, '|')
        return aeronave_formatada

    def inserir_componentes(self, chaves_componentes):
        for chave in chaves_componentes:
            componente = get_componentes().get(chave)
            if componente is None:
                print(f'Chave {chave} não encontrada em componentes')
                continue

            if chave not in self.componentes.keys():
                self.componentes[componente.nome] = componente
            else:
                print(f'Componente {componente.nome} já tem cadastro na Aeronave')
