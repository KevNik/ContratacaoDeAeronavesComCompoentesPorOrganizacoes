from util.data import converte_str_para_data

def imprimir_objetos(cabeçalho, objetos, filtros=None):
    if filtros is not None: print(filtros)
    print(cabeçalho)
    for indice, objeto in enumerate(objetos):
        imprimir_objeto(indice, str(objeto))

def imprimir_objeto(indice, objeto_str):
    formato = '{}{}{}'
    ordem = indice + 1
    separador = '-'
    string_formatado = formato.format(f'{ordem:2d}', separador, objeto_str)
    print(string_formatado)

def imprimir_objetos_associacao_filtros(cabecalho, objetos, filtros=None):
    if filtros is not None: print(filtros)
    print(cabecalho)
    for indice, objeto in enumerate(objetos):
        imprimir_objeto(indice, objeto.str_filtro())


def imprimir_objetos_internos(objetos):
    for objeto in objetos: print('  - ' + str(objeto))

def ler_sair_loop(loop):
    try:
        sair = input('-- sair do loop de ' + loop + '[S]:')
        if sair == 'S': return True
    except IOError:
        pass
    return False


def ler_str(dado, filtro=False, retornar=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and (filtro or retornar): return None
        if len(string) > 0: return string
    except IOError: pass
    print('Erro na leitura do dado: ' + dado)
    return None


def ler_int_positivo(dado, filtro=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and filtro: return None
        int_positivo = int(string)
        if int_positivo > 0: return int_positivo
    except ValueError: pass
    print('Erro na leitura/conversão do inteiro positivo: ' + dado)
    return None


def ler_float_positivo(dado, filtro=False):
    try:
        string = input('- ' + dado + ' : ')
        if len(string) == 0 and filtro: return None
        float_positivo = float(string)
        if float_positivo > 0.0: return float_positivo
    except ValueError: pass
    print('Erro na leitura/conversão do inteiro positivo: ' + dado)
    return None


def ler_data(dado, filtro=False):
    try:
        string = input('- ' + dado + '[dd/mm/aaaa] : ')
        if len(string) == 0 and filtro: return None
        data = converte_str_para_data(string)
        if data is not None: return data
    except IOError: pass
    print('Erro na leitura da data: ' + dado)
    return None

def ler_bool(dado, filtro=False):
    try:
        string = input('- ' + dado + ' [S/N]: ')
        if len(string) == 0 and filtro: return None
        if string == 'S': return True
        if string == 'N': return False
    except IOError: pass
    print('Erro na leitura do bool: ' + dado)
    return None
