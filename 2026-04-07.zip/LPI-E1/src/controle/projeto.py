from util.gerais import imprimir_objetos
from entidades.aeroporto import (Aeroporto, get_aeroportos, inserir_aeroporto, selecionar_aeroportos)
from entidades.componente import (Componente, get_componentes, inserir_componente, selecionar_componentes)

def cadastrar_componentes():
    inserir_componente(Componente('Radar', 'elétrico', True))
    inserir_componente(Componente('Bomba de combustível', 'elétrico', True))
    inserir_componente(Componente('Trem de pouso', 'mecânico', True))
    inserir_componente(Componente('Asa', 'mecânico', True))
    inserir_componente(Componente('Porta de emergência', 'mecânico', False))

def cadastrar_aeroportos():
    inserir_aeroporto(Aeroporto('DOU', 'Dourados', 'Mato grosso do sul', 1500, False))
    inserir_aeroporto(Aeroporto('GRU', 'Guarulhos', 'São Paulo', 2500, False))
    inserir_aeroporto(Aeroporto('VCP', 'Campinas', 'São Paulo', 2500, True))
    inserir_aeroporto(Aeroporto('CGH', 'São Paulo', 'São Paulo', 2500, True))
    inserir_aeroporto(Aeroporto('FLN', 'Florianópolis', 'Santa Catarina', 3500, False))

if __name__ == '__main__':
    print('\nFiscalização de Componentes de uma Aeronave por Aeroporto')
    cadastrar_aeroportos()
    cabeçalho = 'Aeroportos: prefixo - cidade - estado - internacional'
    imprimir_objetos(cabeçalho='\n' + cabeçalho, objetos=get_aeroportos())
    filtros, aeroportos_selecionados = selecionar_aeroportos(tamanho_pista=2500)
    imprimir_objetos(cabeçalho, objetos=aeroportos_selecionados, filtros=filtros)
    filtros, aeroportos_selecionados = selecionar_aeroportos(tamanho_pista=2500, estado='São Paulo')
    imprimir_objetos(cabeçalho, objetos=aeroportos_selecionados, filtros=filtros)
    filtros, aeroportos_selecionados = selecionar_aeroportos(tamanho_pista=2500, estado='São Paulo', internacional=True)
    imprimir_objetos(cabeçalho, objetos=aeroportos_selecionados, filtros=filtros)
    cadastrar_componentes()
    cabeçalho = 'Componentes: nome - tipo - essencial'
    imprimir_objetos(cabeçalho='\n' + cabeçalho, objetos=get_componentes())
    filtros, componentes_selecionados = selecionar_componentes(tipo='mecânico')
    imprimir_objetos(cabeçalho, objetos=componentes_selecionados, filtros=filtros)
    filtros, componentes_selecionados = selecionar_componentes(tipo='mecânico', essencial=True)
    imprimir_objetos(cabeçalho, objetos=componentes_selecionados, filtros=filtros)
    filtros, componentes_selecionados = selecionar_componentes(tipo='mecânico', essencial=True, nome='Asa')
    imprimir_objetos(cabeçalho, objetos=componentes_selecionados, filtros=filtros)