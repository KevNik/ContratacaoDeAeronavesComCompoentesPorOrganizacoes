componentes = {}


def get_componentes(values=False):
    return componentes.values() if values else componentes

def inserir_componente(componente):
    if componente.nome in componentes.keys():
        print(f'Componente {componente.nome} já cadastrado')
    componentes[componente.nome] = componente
    return True

def selecionar_componentes(nome=None, tipo=None, essencial=None):
    componentes_selecionados = []
    filtros = '\nFiltros -- '
    if essencial: filtros += ' essencial'
    elif essencial == False: ''
    if nome is not None: filtros += ' - nome: ' + nome
    if tipo is not None: filtros += ' - tipo: ' + tipo

    for componente in get_componentes(True):
        if essencial in (True, False) and componente.essencial != essencial: continue
        if nome is not None and componente.nome != nome: continue
        if tipo is not None and componente.tipo != tipo: continue
        componentes_selecionados.append(componente)

    return filtros, componentes_selecionados


class Componente:
    def __init__(self, nome, tipo, essencial):
        self.nome = nome
        self.tipo = tipo if tipo in ('elétrico', 'mecânico') else 'indefinido'
        self.essencial = essencial

    def __str__(self):
        if self.essencial: essencial_str = 'essencial'
        else: essencial_str = ''

        formato = '{} {:<20} {} {:<8} {} {:<10} {}'
        componente_formatado = formato.format('|', self.nome, '|', self.tipo, '|', essencial_str, '|')
        return componente_formatado