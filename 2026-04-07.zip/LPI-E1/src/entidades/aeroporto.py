aeroportos = {}

def get_aeroportos(values=False):
    return aeroportos.values() if values else aeroportos


def inserir_aeroporto(aeroporto):
    if aeroporto.prefixo in aeroportos.keys():
        print(f'Aeoroporto {aeroporto.prefixo} já cadastrado')
    aeroportos[aeroporto.prefixo] = aeroporto
    return True


def selecionar_aeroportos(prefixo=None, cidade=None, estado=None, tamanho_pista=None, internacional=None):
    aeroportos_selecionados = []
    filtros = '\nFiltros -- '

    if internacional:
        filtros += ' internacional - '
    elif internacional == False:
        ' nacional - '
    if tamanho_pista is not None: filtros += ' tamanho_pista: ' + str(tamanho_pista)
    if prefixo is not None: filtros += ' - prefixo: ' + prefixo
    if cidade is not None: filtros += ' - cidade: ' + cidade
    if estado is not None: filtros += ' - estado: ' + estado

    for aeroporto in aeroportos:
        if internacional in (True, False) and aeroporto.internacional != internacional: continue
        if prefixo is not None and aeroporto.prefixo != prefixo: continue
        if cidade is not None and aeroporto.cidade != cidade: continue
        if estado is not None and aeroporto.estado != estado: continue
        if tamanho_pista is not None and aeroporto.tamanho_pista < tamanho_pista: continue
        aeroportos_selecionados.append(aeroporto)

    return filtros, aeroportos_selecionados


class Aeroporto:
    def __init__(self, prefixo, cidade, estado, tamanho_pista, internacional):
        self.prefixo = prefixo
        self.cidade = cidade
        self.estado = estado
        self.internacional = internacional
        self.tamanho_pista = tamanho_pista

    def __str__(self):
        if self.internacional: internacional_str = 'internacional'
        else: internacional_str = 'nacional'
        formato = '{} {:<5} {} {:<14} {} {:<20} {} {:>5} {} {:<15} {}'
        aeroporto_formatado = formato.format('|', self.prefixo, '|', self.cidade, '|', self.estado, '|',
                                             str(self.tamanho_pista) + 'M', '|', internacional_str, '|')
        return aeroporto_formatado
