aeronaves = {}

def get_aeronaves(values=False):
    return aeronaves.values() if values else aeronaves

def aeronave(aeronave):
    if aeronave.nome in aeronaves.keys():
        print(f'Aeronave {aeronave.nome} já cadastrada')
    aeronaves[aeronave.nome] = aeronave
    return True

def selecionar_aeronaves(marca=None, modelo=None, prefixo=None, componentes=None):
    aeronaves_selecionadas = []
    filtros = '\nFiltros -- '
    if marca is not None: filtros += ' - marca: ' + marca
    if modelo is not None: filtros += ' - modelo: ' + modelo
    if prefixo is not None: filtros += ' - tipo: ' + prefixo

    for aeronave in get_aeronaves(True):
        if prefixo is not None and aeronave.prefixo != prefixo: continue
        if modelo is not None and aeronave.modelo.startswith(modelo) is False: continue
        if marca is not None and aeronave.marca != marca: continue
        aeronaves_selecionadas.append(aeronave)

    return filtros, aeronaves_selecionadas


class Aeronave:
    def __init__(self, marca, modelo, prefixo):
        self.marca = marca
        self.modelo = modelo
        self.prefixo = prefixo
        self.componentes = {}

    def __str__(self):
        formato = '{} {:<20} {} {:<8} {} {:<10} {}'
        aeronave_formatada = formato.format('|', self.marca, '|', self.modelo, '|', self.prefixo, '|')
        return aeronave_formatada

    def inserir_componente(self, componente):
        if componente.nome not in self.componentes.keys():
            self.componentes[componente.nome] = componente
        else:
            print(f'Componente {componente.nome} já tem cadastro na Aeronave')
